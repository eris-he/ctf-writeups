package cs.com.alg_gen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgGenApplicationTests {

	@Test
	void contextLoads() {
	}

}
