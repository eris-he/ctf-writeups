package cs.com.alg_gen.Helpers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class General_Helpers {

    public static String getTimestamp() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("CST"));

        return simpleDateFormat.format(new Date());
    }

    public static Long calculateDifferenceInMinutes(String lockoutTime) throws Exception {
        long calculatedTotalMinutes = 12345678910L;
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm a z");
        Date lockoutTimeFormatted = simpleDateFormat.parse(lockoutTime);
        Date currentTimeFormatted = simpleDateFormat.parse(getTimestamp());
        long differenceInMilliSeconds = Math.abs(currentTimeFormatted.getTime() - lockoutTimeFormatted.getTime());
        long differenceInHours = (differenceInMilliSeconds / (60 * 60 * 1000)) % 24;
        long differenceInMinutes = (differenceInMilliSeconds / (60 * 1000)) % 60;
        calculatedTotalMinutes = ((differenceInHours * 60) + differenceInMinutes);

        return calculatedTotalMinutes;
    }
}
