package cs.com.alg_gen.Services;

import cs.com.alg_gen.Helpers.General_Helpers;
import org.springframework.stereotype.Service;

@Service
public class TokenGeneratorService {

    public String generate_token() {
        return General_Helpers.getTimestamp().replaceAll("[-: ]", "").substring(6,12);
    }
}
