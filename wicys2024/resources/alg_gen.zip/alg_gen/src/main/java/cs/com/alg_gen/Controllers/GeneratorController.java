package cs.com.alg_gen.Controllers;

import cs.com.alg_gen.Services.TokenGeneratorService;
import org.springframework.web.bind.annotation.*;

@RestController
public class GeneratorController {

    final TokenGeneratorService tokenGeneratorService;

    public GeneratorController(TokenGeneratorService tokenGeneratorService) {
        this.tokenGeneratorService = tokenGeneratorService;
    }

    @GetMapping("/generate")
    public String generate_token(
        @RequestParam(value = "email", required = true) String email) {

        return tokenGeneratorService.generate_token();
    }

    @PostMapping("validate")
    public Boolean verify_token() {

        return true;
    }
}
