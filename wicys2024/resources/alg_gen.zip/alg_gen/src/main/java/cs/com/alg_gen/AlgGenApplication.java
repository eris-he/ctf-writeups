package cs.com.alg_gen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgGenApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgGenApplication.class, args);
	}

}
