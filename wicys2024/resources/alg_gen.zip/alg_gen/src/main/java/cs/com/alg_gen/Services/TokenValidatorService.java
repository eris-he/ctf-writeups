package cs.com.alg_gen.Services;

import cs.com.alg_gen.Helpers.General_Helpers;
import org.springframework.stereotype.Service;

@Service
public class TokenValidatorService {

    public String validate_token(String provided) {
        return General_Helpers.getTimestamp().replaceAll("[-: ]", "").substring(6,12);
    }
}
